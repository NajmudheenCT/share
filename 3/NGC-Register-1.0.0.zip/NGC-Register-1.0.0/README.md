###NGC Plugin Register Guide
### support https/http
* step 1: Import maven project.
* step 2: Copy esdk.zip into ngcplugin directory.
* step 3: Run the maven project and generate the ngcregister-*.zip package.
* step 4: Unzip the package, and run the script in bin directory.
* step 5: Open the url (https://localhost:8088/homePage or http://localhost:8080/homePage) and register the ngc plugin into vCenter server.